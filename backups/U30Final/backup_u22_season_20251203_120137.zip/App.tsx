
import React, { useState, useMemo, useEffect } from 'react';
import { useStore } from './store';
import { DashboardView } from './views/DashboardView';
import { MissionsView } from './views/MissionsView';
import { LogsView } from './views/LogsView'; // U16 Replaced Journal
import { BodyView } from './views/BodyView';
import { AchievementsView } from './views/AchievementsView';
import { ProfileView } from './views/ProfileView';
import { PassivesView } from './views/PassivesView';
import { CalendarView } from './views/CalendarView'; // U18
import { BuffsView } from './views/BuffsView'; // U18.1
import { SeasonView } from './views/SeasonView'; // U22
import { LayoutDashboard, Target, Activity, DoorOpen } from 'lucide-react';
import { LevelUpOverlay } from './components/UIComponents';
import { GateMenu } from './components/GateMenu';
import { Mission, UserStats, StatType } from './types';
import { RewardModal, MissionRewardSummary } from './components/RewardModal';
import { TitleUnlockModal } from './components/TitleUnlockModal';
import { motion, AnimatePresence } from 'framer-motion';

type Tab = 'Dashboard' | 'Misiones' | 'Logs' | 'Físico' | 'Logros' | 'Perfil' | 'Skills' | 'Calendar' | 'Buffs' | 'Season';

const App = () => {
  const {
    state,
    addMission,
    completeMission,
    addBodyRecord,
    openDailyChest,
    canOpenDailyChest,
    upgradePassive,
    getActiveBuffDefinitions,
    getEffectiveStats,
    applyBuff,
    setTitleModalClosed,
    equipTitle,
    equipFrame,
    // U21
    addMilestone,
    incrementMilestonePhase,
    // U22
    claimSeasonReward
  } = useStore();

  const [currentTab, setCurrentTab] = useState<Tab>('Dashboard');
  const [showLevelUp, setShowLevelUp] = useState(false);
  const [prevLevel, setPrevLevel] = useState(1);
  const [isFirstLoad, setIsFirstLoad] = useState(true);
  const [isGateOpen, setIsGateOpen] = useState(false);

  const [lastReward, setLastReward] = useState<MissionRewardSummary | null>(null);
  const [isRewardOpen, setIsRewardOpen] = useState(false);

  useEffect(() => {
    if (isFirstLoad) {
      setPrevLevel(state.stats.level);
      setIsFirstLoad(false);
      return;
    }

    if (state.stats.level > prevLevel) {
      setShowLevelUp(true);
      const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2000/2000-preview.mp3');
      audio.volume = 0.5;
      audio.play().catch(() => { });

      const timer = setTimeout(() => {
        setShowLevelUp(false);
        setPrevLevel(state.stats.level);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [state.stats.level, prevLevel, isFirstLoad]);

  const todayCompletedMissions = useMemo(() => {
    const today = new Date().toDateString();
    return state.missions.filter(m =>
      m.lastCompletedAt && new Date(m.lastCompletedAt).toDateString() === today
    ).length;
  }, [state.missions]);

  const handleMissionCompletion = (mission: Mission) => {
    const prevStatValue = state.stats[mission.targetStat.toLowerCase() as keyof UserStats] as number;
    const newStatValue = prevStatValue + 1;

    const summary: MissionRewardSummary = {
      missionId: mission.id,
      missionTitle: mission.title,
      targetStat: mission.targetStat,
      xpGained: mission.xpReward,
      previousStatValue: prevStatValue,
      newStatValue: newStatValue
    };

    setLastReward(summary);
    completeMission(mission.id);
    setIsRewardOpen(true);
  };

  const renderContent = () => {
    switch (currentTab) {
      case 'Dashboard':
        return (
          <DashboardView
            stats={state.stats}
            todayCompletedMissions={todayCompletedMissions}
            canOpenChest={canOpenDailyChest()}
            onOpenChest={openDailyChest}
            activeBuffs={getActiveBuffDefinitions()}
            effectiveStats={getEffectiveStats()}
            onApplyBuff={applyBuff}
            lastReward={lastReward}
            season={state.seasons[0]}
            seasonProgress={state.currentSeason}
            onOpenSeason={() => setCurrentTab('Season')}
          />
        );
      case 'Misiones':
        return (
          <MissionsView
            missions={state.missions}
            milestones={state.milestones}
            onAddMission={addMission}
            onCompleteMission={handleMissionCompletion}
            onAddMilestone={addMilestone}
            onIncrementMilestone={incrementMilestonePhase}
          />
        );
      case 'Logs':
        return <LogsView logs={state.logs} />;
      case 'Físico':
        return <BodyView records={state.bodyRecords} onAddRecord={addBodyRecord} />;
      case 'Logros':
        return <AchievementsView state={state} onEquipTitle={equipTitle} />;
      case 'Skills':
        return <PassivesView passivePoints={state.passivePoints} passiveLevels={state.passiveLevels} onUpgrade={upgradePassive} />;
      case 'Perfil':
        return <ProfileView stats={state.stats} effectiveStats={getEffectiveStats()} milestones={state.milestones} season={state.seasons[0]} seasonProgress={state.currentSeason} onOpenSeason={() => setCurrentTab('Season')} onEquipTitle={equipTitle} onEquipFrame={equipFrame} />;
      case 'Calendar':
        return <CalendarView />;
      case 'Buffs':
        return <BuffsView activeBuffs={state.activeBuffs} />;
      case 'Season':
        return state.currentSeason ? (
          <SeasonView
            season={state.seasons.find(s => s.id === state.currentSeason!.seasonId) || state.seasons[0]}
            progress={state.currentSeason}
            onClaimReward={claimSeasonReward}
          />
        ) : null;
    }
  };



  return (
    <div className="min-h-screen font-sans selection:bg-blue-500/30 overflow-x-hidden text-slate-200">

      <LevelUpOverlay show={showLevelUp} level={state.stats.level} />

      {state.justUnlockedTitle && (
        <TitleUnlockModal
          title={state.justUnlockedTitle}
          onClose={setTitleModalClosed}
        />
      )}

      {isRewardOpen && lastReward && (
        <RewardModal
          reward={lastReward}
          onClose={() => {
            setIsRewardOpen(false);
            setCurrentTab('Dashboard');
          }}
        />
      )}

      <GateMenu
        isOpen={isGateOpen}
        onClose={() => setIsGateOpen(false)}
        onNavigate={(view) => setCurrentTab(view as Tab)}
      />

      <div className="fixed inset-0 pointer-events-none z-0 opacity-[0.03]" style={{ backgroundImage: 'linear-gradient(#4f46e5 1px, transparent 1px), linear-gradient(90deg, #4f46e5 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>

      <header className="sticky top-0 z-40 bg-[#030712]/80 backdrop-blur-md border-b border-blue-900/30 px-4 h-14 flex items-center justify-between shadow-[0_5px_20px_rgba(0,0,0,0.5)]">
        <div className="w-8"></div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_10px_#3b82f6]"></div>
          <h1 className="font-bold text-blue-100 tracking-[0.2em] uppercase text-xs">
            System <span className="text-blue-500">Nacho</span>
          </h1>
        </div>
        {/* Hamburger Menu Removed */}
      </header>

      <main className="max-w-md mx-auto p-4 relative z-10 min-h-[calc(100vh-140px)]">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>

      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#050914]/90 backdrop-blur-xl border-t border-blue-900/40 pb-safe shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
        <div className="max-w-md mx-auto flex justify-around items-center h-20 px-4 pb-2">
          <NavButton active={currentTab === 'Dashboard'} onClick={() => setCurrentTab('Dashboard')} icon={<LayoutDashboard size={20} />} label="STATUS" />
          <NavButton active={currentTab === 'Misiones'} onClick={() => setCurrentTab('Misiones')} icon={<Target size={20} />} label="QUESTS" />
          <NavButton active={currentTab === 'Físico'} onClick={() => setCurrentTab('Físico')} icon={<Activity size={20} />} label="HEALTH" />
          <NavButton active={isGateOpen} onClick={() => setIsGateOpen(true)} icon={<DoorOpen size={20} />} label="GATE" />
        </div>
      </nav>
    </div >
  );
};

const NavButton: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button
    onClick={onClick}
    className={`flex flex-col items-center justify-center w-full h-full pt-2 transition-all duration-300 group`}
  >
    <div className={`
      relative p-2.5 rounded-xl transition-all duration-300
      ${active
        ? 'text-white bg-blue-600 shadow-[0_0_15px_rgba(37,99,235,0.6)] translate-y-[-5px]'
        : 'text-slate-500 group-hover:text-blue-400 group-hover:bg-blue-900/20'
      }
    `}>
      {icon}
    </div>
    <span className={`text-[9px] mt-1.5 font-bold tracking-widest transition-colors ${active ? 'text-blue-400' : 'text-slate-600'}`}>{label}</span>
  </button>
);

export default App;
