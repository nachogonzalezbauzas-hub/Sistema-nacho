
import React from 'react';
import { UserStats, StatType, ActiveBuff, BuffDefinition, SeasonDefinition, SeasonProgress } from '../types';
import { Card, StatCard, Button, SeasonBadge } from '../components/UIComponents';
import { CheckCircle2, Timer, Flame, Beaker } from 'lucide-react';
import { DailyChest } from '../components/DailyChest';
import { MissionRewardSummary } from '../components/RewardModal';
import { TITLES, AVATAR_FRAMES } from '../titles';
import { EffectiveStats } from '../types';

interface DashboardViewProps {
  stats: UserStats;
  todayCompletedMissions: number;
  // U14 Props
  canOpenChest: boolean;
  onOpenChest: () => any;
  activeBuffs: BuffDefinition[];
  effectiveStats: EffectiveStats;
  onApplyBuff: (id: any) => void;
  lastReward?: MissionRewardSummary | null;
  // U22 Props
  season?: SeasonDefinition;
  seasonProgress?: SeasonProgress;
  onOpenSeason?: () => void;
  // Legacy compatibility
  onClaimChest?: any;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  stats,
  todayCompletedMissions,
  canOpenChest,
  onOpenChest,
  activeBuffs,
  effectiveStats,
  onApplyBuff,
  lastReward,
  season,
  seasonProgress,
  onOpenSeason
}) => {
  const xpPercentage = Math.min(100, (stats.xpCurrent / stats.xpForNextLevel) * 100);
  const equippedTitle = TITLES.find(t => t.id === stats.equippedTitleId);
  const equippedFrame = AVATAR_FRAMES.find(f => f.id === stats.selectedFrameId) || AVATAR_FRAMES[0];

  const seasonPercent = seasonProgress && season
    ? Math.min(100, (seasonProgress.seasonXP / (season.xpTargets[seasonProgress.rank === 'S' ? 'S' : 'A'] || 5000)) * 100)
    : 0;

  return (
    <div className="space-y-6 pb-24 animate-in fade-in slide-in-from-bottom-8 duration-700">

      {/* ACTIVE BUFFS STRIP */}
      {activeBuffs.length > 0 && (
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide -mx-2 px-2">
          {activeBuffs.map(buff => (
            <div key={buff.id} className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-950/40 border border-blue-500/30 whitespace-nowrap animate-in zoom-in duration-300">
              <span className="text-lg">{buff.icon}</span>
              <div className="flex flex-col leading-none">
                <span className="text-[10px] font-bold text-blue-200 uppercase">{buff.name}</span>
                <span className="text-[8px] font-mono text-blue-400/70">ACTIVE</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* HERO CARD */}
      <div className="relative group">
        <div className="absolute inset-0 bg-blue-600/10 blur-xl rounded-2xl group-hover:bg-blue-600/20 transition-all duration-500"></div>
        <Card className={`relative overflow-hidden border-blue-400/30 bg-[#0a0f1e]/90 ${equippedFrame.id !== 'default' ? 'shadow-[0_0_20px_rgba(59,130,246,0.1)]' : ''}`}>
          <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none select-none">
            <div className="text-9xl font-black text-blue-500 font-mono tracking-tighter">S-RANK</div>
          </div>

          <div className="relative z-10 flex flex-col gap-6">
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-900/50 text-blue-300 border border-blue-500/30">
                    PLAYER SYSTEM
                  </span>
                  <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_8px_#22c55e]"></div>
                </div>
                <h1 className="text-4xl font-black text-white tracking-tighter drop-shadow-[0_0_10px_rgba(255,255,255,0.3)]">
                  NACHO
                </h1>

                {/* U22 Season Badge */}
                {season && seasonProgress && (
                  <div className="mt-2 mb-1">
                    <SeasonBadge
                      name={season.id}
                      rank={seasonProgress.rank}
                      progress={seasonPercent}
                      onClick={onOpenSeason}
                    />
                  </div>
                )}

                {equippedTitle ? (
                  <p className="text-blue-400 font-bold text-xs font-mono tracking-widest uppercase mt-1 animate-pulse drop-shadow-[0_0_5px_rgba(59,130,246,0.6)]">
                    {equippedTitle.name}
                  </p>
                ) : (
                  <p className="text-slate-500/80 text-xs font-mono tracking-widest uppercase mt-1">
                    Shadow Monarch Candidate
                  </p>
                )}
              </div>

              <div className="flex flex-col items-end">
                <span className="text-xs text-slate-500 font-bold uppercase tracking-widest mb-1">Level</span>
                <div className="relative">
                  <div className="absolute inset-0 bg-blue-500 blur-lg opacity-40"></div>
                  <span className="relative text-5xl font-black text-white font-mono italic tracking-tighter drop-shadow-[0_0_10px_rgba(59,130,246,0.8)]">
                    {stats.level}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold font-mono text-blue-300/70 uppercase">
                <span>Experience</span>
                <span>{stats.xpCurrent} <span className="text-slate-600">/</span> {stats.xpForNextLevel}</span>
              </div>
              <div className="h-3 bg-slate-900/80 rounded-sm overflow-hidden border border-slate-700/50 relative shadow-inner">
                <div className={`h-full bg-gradient-to-r from-blue-700 via-blue-500 to-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.6)] relative overflow-hidden transition-all duration-700 ease-out ${xpPercentage >= 100 ? 'animate-shake' : ''}`} style={{ width: `${xpPercentage}%` }}>
                  <div className="absolute inset-0 bg-white/20 animate-[shimmer_2s_infinite]"></div>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* DAILY CHEST */}
      <DailyChest isAvailable={canOpenChest} onClaim={onOpenChest} />

      {/* Effective Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        <StatCard stat="Strength" value={effectiveStats.strength} highlight={lastReward?.targetStat === 'Strength'} />
        <StatCard stat="Vitality" value={effectiveStats.vitality} highlight={lastReward?.targetStat === 'Vitality'} />
        <StatCard stat="Agility" value={effectiveStats.agility} highlight={lastReward?.targetStat === 'Agility'} />
        <StatCard stat="Intelligence" value={effectiveStats.intelligence} highlight={lastReward?.targetStat === 'Intelligence'} />
        <StatCard stat="Fortune" value={effectiveStats.fortune} highlight={lastReward?.targetStat === 'Fortune'} />
        <StatCard stat="Metabolism" value={effectiveStats.metabolism} highlight={lastReward?.targetStat === 'Metabolism'} />
      </div>

      <Card className="flex items-center justify-between border-l-4 border-l-green-500 bg-gradient-to-r from-green-900/10 to-transparent">
        <div className="flex items-center gap-4">
          <div className="p-2 bg-green-500/20 rounded-lg text-green-400 animate-pulse-fast"><CheckCircle2 size={24} /></div>
          <div>
            <span className="block text-slate-200 font-bold text-sm uppercase tracking-wide">Daily Consistency</span>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-mono">Completed Today</span>
              {stats.streak > 1 && (
                <span className="flex items-center gap-1 text-[10px] font-bold bg-orange-500/20 text-orange-400 px-1.5 py-0.5 rounded border border-orange-500/30"><Flame size={10} className="fill-orange-500" /> {stats.streak} DAY STREAK</span>
              )}
            </div>
          </div>
        </div>
        <span className="text-3xl font-black text-green-400 drop-shadow-[0_0_5px_rgba(34,197,94,0.5)] font-mono">{todayCompletedMissions}</span>
      </Card>

      {/* Debug Buffs */}
      <div className="pt-4 border-t border-slate-800">
        <h4 className="text-[10px] font-bold text-slate-600 uppercase mb-2">Debug Potions</h4>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={() => onApplyBuff('coffee_focus')} className="text-xs border border-slate-700 bg-slate-900">☕ Coffee</Button>
          <Button variant="ghost" onClick={() => onApplyBuff('gym_boost')} className="text-xs border border-slate-700 bg-slate-900">🏋️ Gym</Button>
          <Button variant="ghost" onClick={() => onApplyBuff('lucky_day')} className="text-xs border border-slate-700 bg-slate-900">🍀 Luck</Button>
        </div>
      </div>
    </div>
  );
};
