
import React, { useState } from 'react';
import { Mission, StatType, Milestone } from '../types';
import { Card, Button, Input, Select, Modal, TextArea, StatBadge, TemplateChip, StreakBadge, SegmentedControl, MilestoneCard } from '../components/UIComponents';
import { Plus, Sword, AlertCircle, RefreshCw, Lock } from 'lucide-react';
import { MISSION_TEMPLATES, MissionTemplate } from '../missionTemplates';
import { isMissionAvailableToday } from '../store';

interface MissionsViewProps {
  missions: Mission[];
  milestones: Milestone[];
  onAddMission: (mission: Omit<Mission, 'id' | 'lastCompletedAt'>) => void;
  onCompleteMission: (mission: Mission) => void;
  onAddMilestone: (milestone: any) => void;
  onIncrementMilestone: (id: string) => void;
}

type FilterType = 'All' | 'Daily' | 'Completed' | StatType;

const MissionItem: React.FC<{ mission: Mission; onComplete: () => void }> = ({ mission, onComplete }) => {
  const isCompletedToday = mission.lastCompletedAt &&
    new Date(mission.lastCompletedAt).toDateString() === new Date().toDateString();

  const isAvailableToday = isMissionAvailableToday(mission, new Date());

  // Can complete if: Available Today AND (Not completed today OR Not Daily)
  // Logic: If daily/recurring, can only complete once per day.
  const canComplete = isAvailableToday && (!mission.isDaily || !isCompletedToday);

  // Visual state
  const isDimmed = !isAvailableToday;

  return (
    <div className={`relative group transition-all duration-300 
      ${!canComplete ? 'opacity-50 grayscale-[0.5] scale-[0.98]' : 'hover:scale-[1.01]'}
      ${isDimmed ? 'opacity-30' : ''}
    `}>

      {/* Dynamic Glow U8 */}
      {canComplete && (
        <div className={`absolute inset-0 blur-md rounded-xl -z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-500
          ${mission.targetStat === 'Strength' ? 'bg-cyan-500/10' : ''}
          ${mission.targetStat === 'Vitality' ? 'bg-red-500/10' : ''}
          ${mission.targetStat === 'Agility' ? 'bg-yellow-500/10' : ''}
          ${mission.targetStat === 'Intelligence' ? 'bg-purple-500/10' : ''}
          ${mission.targetStat === 'Fortune' ? 'bg-green-500/10' : ''}
          ${mission.targetStat === 'Metabolism' ? 'bg-blue-500/10' : ''}
        `}></div>
      )}

      <Card className={`
        relative border overflow-hidden
        ${isCompletedToday ? 'bg-slate-900/50 border-slate-700/50' : 'bg-[#0a0f1e]/80 hover:border-blue-400/60 border-blue-500/20'}
      `}>
        {canComplete && <div className="absolute top-0 left-0 w-16 h-16 bg-gradient-to-br from-blue-500/10 to-transparent pointer-events-none"></div>}

        <div className="flex justify-between items-stretch gap-4 relative z-10">
          <div className="flex-1 flex flex-col justify-between py-1">
            <div>
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                {(mission.isDaily || mission.frequency === 'daily' || mission.frequency === 'weekly') && (
                  <span className={`flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded border ${isCompletedToday ? 'bg-slate-800 text-slate-500 border-slate-700' : 'bg-blue-900/40 text-blue-300 border-blue-500/30'}`}>
                    <RefreshCw size={10} className={canComplete ? "animate-spin-slow" : ""} />
                    {mission.frequency === 'weekly' ? 'WEEKLY' : 'DAILY'}
                  </span>
                )}
                {!isAvailableToday && (
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded border bg-slate-800 text-slate-500 border-slate-700">
                    LOCKED
                  </span>
                )}
                <StatBadge stat={mission.targetStat} />
              </div>

              <h3 className={`font-bold text-lg leading-tight mb-1 transition-all ${isCompletedToday ? 'text-slate-500 line-through decoration-slate-600' : 'text-slate-100 group-hover:text-blue-100 group-hover:drop-shadow-[0_0_5px_rgba(59,130,246,0.5)]'}`}>
                {mission.title}
              </h3>

              <div className="flex items-center gap-2 mt-1 mb-2">
                <StreakBadge value={mission.streak || 0} />
              </div>

              <p className="text-xs text-slate-400/80 line-clamp-2 leading-relaxed font-medium">
                {mission.detail}
              </p>
            </div>

            <div className="mt-2 flex items-center">
              <div className={`px-2 py-1 rounded bg-[#030712] border border-blue-500/30 flex items-center gap-1.5 ${canComplete ? 'shadow-[0_0_10px_rgba(37,99,235,0.2)]' : ''}`}>
                <span className="text-[10px] text-slate-500 font-bold uppercase">Reward</span>
                <span className={`text-xs font-mono font-bold ${isCompletedToday ? 'text-slate-500' : 'text-blue-400 drop-shadow-[0_0_5px_rgba(59,130,246,0.8)]'}`}>
                  +{mission.xpReward} XP
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center">
            <button
              onClick={onComplete}
              disabled={!canComplete}
              className={`
                shrink-0 relative flex items-center justify-center w-14 h-14 rounded-lg border transition-all duration-300
                ${!canComplete
                  ? 'bg-slate-900 border-slate-700 text-slate-600 cursor-not-allowed'
                  : 'bg-blue-600/10 border-blue-500/50 text-blue-400 hover:bg-blue-500 hover:text-white hover:border-blue-400 hover:shadow-[0_0_15px_rgba(37,99,235,0.5)] active:scale-90 group-hover:animate-pulse-fast'
                }
              `}
            >
              {isCompletedToday ? (
                <div className="flex flex-col items-center">
                  <Lock size={18} />
                  <span className="text-[9px] font-mono mt-0.5">Done</span>
                </div>
              ) : !isAvailableToday ? (
                <div className="flex flex-col items-center opacity-50">
                  <Lock size={18} />
                  <span className="text-[9px] font-mono mt-0.5">Soon</span>
                </div>
              ) : (
                <Sword size={24} className={canComplete ? "drop-shadow-[0_0_5px_rgba(255,255,255,0.5)]" : ""} />
              )}
            </button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export const MissionsView: React.FC<MissionsViewProps> = ({
  missions,
  milestones = [],
  onAddMission,
  onCompleteMission,
  onAddMilestone,
  onIncrementMilestone
}) => {
  const [activeTab, setActiveTab] = useState<'Normal Missions' | 'Epic Missions'>('Normal Missions');
  const [filter, setFilter] = useState<FilterType>('All');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // New Mission Form State
  const [newTitle, setNewTitle] = useState('');
  const [newDetail, setNewDetail] = useState('');
  const [newStat, setNewStat] = useState<StatType>('Strength');
  const [newXp, setNewXp] = useState(10);
  const [newIsDaily, setNewIsDaily] = useState(false);

  const handleAddMission = () => {
    if (!newTitle) return;
    onAddMission({
      title: newTitle,
      detail: newDetail,
      targetStat: newStat,
      xpReward: newXp,
      isDaily: newIsDaily,
      frequency: newIsDaily ? 'daily' : 'always'
    });
    setIsModalOpen(false);
    // Reset form
    setNewTitle('');
    setNewDetail('');
    setNewStat('Strength');
    setNewXp(10);
    setNewIsDaily(false);
  };

  const handleTemplateClick = (template: MissionTemplate) => {
    setNewTitle(template.label);
    setNewDetail(template.description || '');
    setNewStat(template.targetStat);
    setNewXp(template.xpReward);
    setNewIsDaily(template.category === 'Habit');
  };

  // Filter Logic
  const filteredMissions = missions.filter(m => {
    if (filter === 'All') return true;
    if (filter === 'Daily') return m.isDaily || m.frequency === 'daily';
    if (filter === 'Completed') return m.lastCompletedAt && new Date(m.lastCompletedAt).toDateString() === new Date().toDateString();
    return m.targetStat === filter;
  });

  // Sort: Available first, then by title
  const sortedMissions = [...filteredMissions].sort((a, b) => {
    const aAvailable = isMissionAvailableToday(a, new Date());
    const bAvailable = isMissionAvailableToday(b, new Date());
    if (aAvailable === bAvailable) return 0;
    return aAvailable ? -1 : 1;
  });

  // Temporary helper to add a test milestone
  const addTestMilestone = () => {
    onAddMilestone({
      title: "Shadow Rider",
      description: "Obtain the motorcycle license and master the road.",
      category: "Skill",
      targetDate: "2025-12-31",
      phases: [
        { title: "Study Theory", description: "Read the manual and pass the theory exam.", requiredActions: 5 },
        { title: "Practical Lessons", description: "Complete driving lessons.", requiredActions: 10 },
        { title: "Final Exam", description: "Pass the practical exam.", requiredActions: 1 }
      ],
      reward: {
        xpBonus: 500,
        unlockTitleId: 'shadow_rider',
        unlockFrameId: 'storm_rider',
        statBonus: { agility: 5, perception: 3 }
      }
    });
  };

  return (
    <div className="space-y-6 pb-24 animate-in fade-in slide-in-from-bottom-8 duration-700">

      {/* Tab Selector */}
      <SegmentedControl
        options={['Normal Missions', 'Epic Missions']}
        selected={activeTab}
        onChange={(val) => setActiveTab(val as any)}
      />

      {activeTab === 'Normal Missions' ? (
        <>
          {/* Filters */}
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide -mx-2 px-2">
            {['All', 'Daily', 'Strength', 'Vitality', 'Agility', 'Intelligence', 'Fortune', 'Metabolism'].map(f => (
              <button
                key={f}
                onClick={() => setFilter(f as FilterType)}
                className={`
                  px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider whitespace-nowrap transition-all
                  ${filter === f
                    ? 'bg-blue-600 text-white shadow-[0_0_10px_rgba(37,99,235,0.5)]'
                    : 'bg-slate-900/50 text-slate-500 border border-slate-800 hover:border-blue-500/30 hover:text-blue-400'}
                `}
              >
                {f}
              </button>
            ))}
          </div>

          {/* Mission List */}
          <div className="space-y-3">
            {sortedMissions.length === 0 ? (
              <div className="text-center py-12 opacity-50">
                <Sword size={48} className="mx-auto mb-4 text-slate-700" />
                <p className="text-slate-500 font-mono text-xs">No missions found for this filter.</p>
              </div>
            ) : (
              sortedMissions.map(mission => (
                <MissionItem
                  key={mission.id}
                  mission={mission}
                  onComplete={() => onCompleteMission(mission)}
                />
              ))
            )}
          </div>

          {/* Add Button */}
          <button
            onClick={() => setIsModalOpen(true)}
            className="fixed bottom-24 right-4 w-14 h-14 bg-blue-600 rounded-full flex items-center justify-center text-white shadow-[0_0_20px_rgba(37,99,235,0.5)] hover:scale-110 hover:bg-blue-500 transition-all z-30 active:scale-95"
          >
            <Plus size={24} />
          </button>
        </>
      ) : (
        /* Epic Missions Tab */
        <div className="space-y-4">
          {milestones.length === 0 ? (
            <div className="text-center py-12 opacity-50 border border-dashed border-slate-800 rounded-xl">
              <Sword size={48} className="mx-auto mb-4 text-slate-700" />
              <p className="text-slate-500 font-mono text-xs mb-4">No Epic Missions active.</p>
              <Button variant="secondary" onClick={addTestMilestone} className="mx-auto">
                Start "Shadow Rider" Arc
              </Button>
            </div>
          ) : (
            milestones.map(milestone => (
              <MilestoneCard
                key={milestone.id}
                milestone={milestone}
                onAction={() => onIncrementMilestone(milestone.id)}
              />
            ))
          )}

          {/* Debug/Test Button for adding more milestones */}
          {milestones.length > 0 && (
            <div className="pt-8 flex justify-center opacity-50 hover:opacity-100 transition-opacity">
              <Button variant="ghost" onClick={addTestMilestone} className="text-[10px]">
                + Debug: Add Test Milestone
              </Button>
            </div>
          )}
        </div>
      )}

      {/* Add Mission Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="New Mission">
        <div className="space-y-4">
          {/* Templates */}
          <div>
            <label className="text-xs text-slate-500 font-bold uppercase mb-2 block">Quick Templates</label>
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {MISSION_TEMPLATES.map((t, i) => (
                <TemplateChip key={i} template={t} onClick={() => handleTemplateClick(t)} />
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-xs text-slate-500 font-bold uppercase mb-1 block">Title</label>
              <Input placeholder="e.g. 100 Pushups" value={newTitle} onChange={e => setNewTitle(e.target.value)} />
            </div>

            <div>
              <label className="text-xs text-slate-500 font-bold uppercase mb-1 block">Target Stat</label>
              <Select value={newStat} onChange={e => setNewStat(e.target.value as StatType)}>
                <option value="Strength">Strength</option>
                <option value="Vitality">Vitality</option>
                <option value="Agility">Agility</option>
                <option value="Intelligence">Intelligence</option>
                <option value="Fortune">Fortune</option>
                <option value="Metabolism">Metabolism</option>
              </Select>
            </div>

            <div className="flex gap-4">
              <div className="flex-1">
                <label className="text-xs text-slate-500 font-bold uppercase mb-1 block">XP Reward</label>
                <Input type="number" value={newXp} onChange={e => setNewXp(Number(e.target.value))} />
              </div>
              <div className="flex-1 flex items-end pb-3">
                <label className="flex items-center gap-2 cursor-pointer group">
                  <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${newIsDaily ? 'bg-blue-600 border-blue-500' : 'bg-slate-900 border-slate-700 group-hover:border-blue-500/50'}`}>
                    {newIsDaily && <Plus size={14} className="text-white" />}
                  </div>
                  <span className={`text-xs font-bold uppercase ${newIsDaily ? 'text-blue-400' : 'text-slate-500 group-hover:text-slate-300'}`}>Daily Habit</span>
                </label>
                <input type="checkbox" className="hidden" checked={newIsDaily} onChange={e => setNewIsDaily(e.target.checked)} />
              </div>
            </div>

            <div>
              <label className="text-xs text-slate-500 font-bold uppercase mb-1 block">Description</label>
              <TextArea placeholder="Mission details..." value={newDetail} onChange={e => setNewDetail(e.target.value)} rows={3} />
            </div>
          </div>

          <div className="pt-4">
            <Button onClick={handleAddMission} className="w-full">Create Mission</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
