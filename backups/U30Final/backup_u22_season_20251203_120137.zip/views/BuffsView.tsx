import React, { useState, useEffect } from 'react';
import { Flame, Clock, Shield } from 'lucide-react';
import { ActiveBuff } from '../types';
import { BUFF_DEFINITIONS } from '../buffs';
import { motion } from 'framer-motion';

interface BuffsViewProps {
    activeBuffs: ActiveBuff[];
}

export const BuffsView: React.FC<BuffsViewProps> = ({ activeBuffs = [] }) => {
    const [now, setNow] = useState(new Date());

    useEffect(() => {
        const timer = setInterval(() => setNow(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);

    const getBuffDetails = (buff: ActiveBuff) => {
        const def = BUFF_DEFINITIONS.find(b => b.id === buff.id);
        if (!def) return null;

        const expires = new Date(buff.expiresAt);
        const timeLeft = Math.max(0, Math.floor((expires.getTime() - now.getTime()) / 60000));
        const timeLeftSeconds = Math.max(0, Math.floor((expires.getTime() - now.getTime()) / 1000));

        const minutes = Math.floor(timeLeftSeconds / 60);
        const seconds = timeLeftSeconds % 60;

        return { ...def, timeLeft: `${minutes}:${seconds.toString().padStart(2, '0')}` };
    };

    return (
        <div className="space-y-6 pb-24">
            <header className="mb-6">
                <h2 className="text-2xl font-bold text-white tracking-wider flex items-center gap-3">
                    <Flame className="text-orange-500" size={28} />
                    ACTIVE BUFFS
                </h2>
                <p className="text-slate-400 text-sm mt-1">Manage your active effects</p>
            </header>

            {activeBuffs.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-slate-500 bg-slate-900/50 rounded-xl border border-slate-800">
                    <Shield size={48} className="mb-4 opacity-20" />
                    <p>No active buffs</p>
                </div>
            ) : (
                <div className="grid gap-4">
                    {activeBuffs.map((buff, index) => {
                        const details = getBuffDetails(buff);
                        if (!details) return null;

                        const expires = new Date(buff.expiresAt);
                        const totalDuration = 60; // minutes
                        const timeLeftMinutes = Math.max(0, (expires.getTime() - now.getTime()) / 60000);
                        const progress = Math.max(0, Math.min(100, (timeLeftMinutes / totalDuration) * 100));

                        let progressColor = 'bg-green-500';
                        if (progress < 30) progressColor = 'bg-red-500';
                        else if (progress < 60) progressColor = 'bg-yellow-500';

                        return (
                            <motion.div
                                key={buff.id}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: index * 0.1, duration: 0.3 }}
                                className="bg-slate-900/80 border border-orange-900/30 rounded-xl p-4 flex items-center gap-4 shadow-lg shadow-orange-900/10 hover:border-orange-500/40 transition-all"
                            >
                                <div className="w-12 h-12 rounded-full bg-orange-500/10 flex items-center justify-center border border-orange-500/20 text-2xl">
                                    {details.icon}
                                </div>
                                <div className="flex-1">
                                    <h3 className="font-bold text-orange-100">{details.name}</h3>
                                    <p className="text-xs text-orange-300/70 mb-2">{details.description}</p>
                                    <div className="h-1 bg-slate-950/50 rounded-full overflow-hidden">
                                        <div className={`h-full ${progressColor} transition-all duration-1000`} style={{ width: `${progress}%` }}></div>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <div className="flex items-center gap-1 text-xs text-slate-400 bg-slate-950/50 px-2 py-1 rounded-md">
                                        <Clock size={12} />
                                        <span>{details.timeLeft}</span>
                                    </div>
                                </div>
                            </motion.div>
                        );
                    })}
                </div>
            )}
        </div>
    );
};
