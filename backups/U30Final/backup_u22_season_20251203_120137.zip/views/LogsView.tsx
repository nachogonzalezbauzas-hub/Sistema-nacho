
import React, { useState, useMemo } from 'react';
import { LogEntry, LogCategory } from '../types';
import { Card, Input, LogCategoryBadge } from '../components/UIComponents';
import { Search, Target, Swords, Heart, Flame, Trophy, Terminal, Calendar, Sparkles, Check } from 'lucide-react';

interface LogsViewProps {
  logs: LogEntry[];
}

export const LogsView: React.FC<LogsViewProps> = ({ logs }) => {
  const [filter, setFilter] = useState<'All' | LogCategory>('All');
  const [search, setSearch] = useState('');

  const filteredLogs = useMemo(() => {
    return logs.filter(log => {
      const matchesFilter = filter === 'All' || log.category === filter;
      const logMessage = log.message || (log as any).title || '';
      const logDetails = log.details || (log as any).description || '';

      const matchesSearch = logMessage.toLowerCase().includes(search.toLowerCase()) ||
        logDetails.toLowerCase().includes(search.toLowerCase());
      return matchesFilter && matchesSearch;
    });
  }, [logs, filter, search]);

  const groupedLogs = useMemo(() => {
    const groups: Record<string, LogEntry[]> = {};
    filteredLogs.forEach(log => {
      const date = new Date(log.timestamp);
      const today = new Date();
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);

      let key = date.toLocaleDateString();
      if (date.toDateString() === today.toDateString()) key = 'Today';
      else if (date.toDateString() === yesterday.toDateString()) key = 'Yesterday';

      if (!groups[key]) groups[key] = [];
      groups[key].push(log);
    });
    return groups;
  }, [filteredLogs]);

  // Daily Stats
  const todayStats = useMemo(() => {
    const todayStr = new Date().toDateString();
    const todayLogs = logs.filter(l => new Date(l.timestamp).toDateString() === todayStr);

    return {
      missions: todayLogs.filter(l => l.category === 'Mission').length,
      xp: todayLogs.reduce((acc, l) => acc + (l.xpChange || 0), 0),
      milestones: todayLogs.filter(l => l.category === 'Milestone').length
    };
  }, [logs]);

  const getIcon = (category: LogCategory) => {
    switch (category) {
      case 'Mission': return <Target size={18} className="text-blue-400" />;
      case 'LevelUp': return <Swords size={18} className="text-cyan-400" />;
      case 'Health': return <Heart size={18} className="text-pink-400" />;
      case 'Streak': return <Flame size={18} className="text-yellow-400" />;
      case 'Achievement': return <Trophy size={18} className="text-purple-400" />;
      case 'Milestone': return <Sparkles size={18} className="text-amber-400" />;
      default: return <Terminal size={18} className="text-slate-400" />;
    }
  };

  const FilterPill = ({ cat, label }: { cat: 'All' | LogCategory, label: string }) => (
    <button
      onClick={() => setFilter(cat)}
      className={`
        px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider transition-all duration-300 border whitespace-nowrap
        ${filter === cat
          ? 'bg-blue-600 text-white border-blue-400 shadow-[0_0_10px_rgba(37,99,235,0.5)] scale-105'
          : 'bg-slate-900 text-slate-400 border-slate-700 hover:bg-slate-800 hover:border-slate-500'
        }
      `}
    >
      {label}
    </button>
  );

  return (
    <div className="pb-24 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">

      {/* Header */}
      <div className="flex justify-between items-end px-1 pb-2 border-b border-blue-900/30">
        <div>
          <h2 className="text-2xl font-black text-white italic tracking-tighter drop-shadow-md">SYSTEM LOGS</h2>
          <p className="text-xs text-blue-400/80 font-mono uppercase tracking-widest mt-1">Timeline Events</p>
        </div>
      </div>

      {/* Daily Summary Card */}
      <div className="relative overflow-hidden rounded-xl border border-blue-500/30 bg-gradient-to-r from-blue-950/40 to-slate-900/40 p-4">
        <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
          <Calendar size={64} className="text-blue-400" />
        </div>
        <h3 className="text-xs font-bold text-blue-300 uppercase tracking-widest mb-3">Daily Summary</h3>
        <div className="flex gap-6">
          <div>
            <div className="text-2xl font-black text-white">{todayStats.missions}</div>
            <div className="text-[10px] text-slate-500 font-bold uppercase">Missions</div>
          </div>
          <div>
            <div className="text-2xl font-black text-blue-400">+{todayStats.xp}</div>
            <div className="text-[10px] text-slate-500 font-bold uppercase">XP Gained</div>
          </div>
          <div>
            <div className="text-2xl font-black text-amber-400">{todayStats.milestones}</div>
            <div className="text-[10px] text-slate-500 font-bold uppercase">Milestones</div>
          </div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="space-y-3">
        <div className="relative">
          <Input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search logs..."
            className="pl-9 h-10 text-xs"
          />
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" size={14} />
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
          <FilterPill cat="All" label="All" />
          <FilterPill cat="Mission" label="Missions" />
          <FilterPill cat="LevelUp" label="Level Up" />
          <FilterPill cat="Health" label="Health" />
          <FilterPill cat="Streak" label="Streaks" />
          <FilterPill cat="Achievement" label="Awards" />
          <FilterPill cat="Milestone" label="Milestones" />
          <FilterPill cat="System" label="System" />
        </div>
      </div>

      {/* Timeline */}
      <div className="space-y-6">
        {Object.entries(groupedLogs).map(([dateLabel, groupLogs]) => (
          <div key={dateLabel} className="space-y-3 animate-in slide-in-from-bottom-2 duration-500">
            <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest sticky top-14 bg-[#030712]/90 backdrop-blur py-2 z-10 border-b border-slate-800/50">
              {dateLabel}
            </h4>

            {groupLogs.map(log => (
              <Card
                key={log.id}
                className="group flex gap-4 p-3 bg-slate-900/60 border-blue-900/20 hover:border-blue-500/30 hover:shadow-[0_0_15px_rgba(37,99,235,0.1)] transition-all"
              >
                <div className="flex flex-col items-center gap-2">
                  <div className={`p-2 rounded-lg bg-slate-950 border border-slate-800 ${log.category === 'LevelUp' ? 'border-cyan-500/50 shadow-[0_0_10px_rgba(6,182,212,0.3)]' : ''}`}>
                    {getIcon(log.category)}
                  </div>
                  <div className="h-full w-[1px] bg-slate-800 group-last:hidden"></div>
                </div>

                <div className="flex-1 pb-2">
                  <div className="flex justify-between items-start mb-1">
                    <h5 className="font-bold text-sm text-slate-200">{log.message || (log as any).title}</h5>
                    <span className="text-[9px] font-mono text-slate-500">
                      {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 mb-2">
                    <LogCategoryBadge category={log.category} />
                    {log.xpChange && (
                      <span className="text-[9px] font-bold text-blue-400 font-mono">+{log.xpChange} XP</span>
                    )}
                  </div>

                  {(log.details || (log as any).description) && (
                    <p className="text-xs text-slate-400 leading-relaxed font-light">
                      {log.details || (log as any).description}
                    </p>
                  )}
                </div>
              </Card>
            ))}
          </div>
        ))}

        {filteredLogs.length === 0 && (
          <div className="text-center py-12 px-6 border border-dashed border-slate-800 rounded-xl bg-slate-900/20">
            <div className="inline-block p-3 rounded-full bg-slate-900 mb-3 border border-slate-700">
              <Terminal className="text-slate-600" size={24} />
            </div>
            <p className="text-slate-500 font-bold uppercase tracking-wider text-xs">No logs found</p>
          </div>
        )}
      </div>
    </div>
  );
};
