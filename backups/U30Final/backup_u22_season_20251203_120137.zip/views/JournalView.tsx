import React, { useState } from 'react';
import { JournalEntry } from '../types';
import { Card, Button, TextArea, Modal } from '../components/UIComponents';
import { PenLine, Calendar, FileText } from 'lucide-react';

interface JournalViewProps {
  entries: JournalEntry[];
  onAddEntry: (text: string) => void;
}

export const JournalView: React.FC<JournalViewProps> = ({ entries, onAddEntry }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [text, setText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    onAddEntry(text);
    setIsModalOpen(false);
    setText('');
  };

  const formatDate = (isoString: string) => {
    return new Date(isoString).toLocaleDateString('es-ES', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="pb-24 space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end mb-6 px-1 border-b border-blue-900/30 pb-2">
        <div>
          <h2 className="text-2xl font-black text-white italic tracking-tighter drop-shadow-md">LOGS</h2>
          <p className="text-xs text-blue-400/80 font-mono uppercase tracking-widest mt-1">System Records</p>
        </div>
        <Button onClick={() => setIsModalOpen(true)} className="h-9 text-xs px-3">
          <PenLine size={14} /> WRITE
        </Button>
      </div>

      <div className="space-y-4">
        {entries.map(entry => (
          <Card key={entry.id} className="group hover:border-blue-500/40 border-l-4 border-l-blue-600 pl-5">
            <div className="flex items-center gap-2 text-[10px] text-blue-400 font-mono mb-3 uppercase tracking-wider bg-blue-950/30 w-fit px-2 py-0.5 rounded border border-blue-900/30">
              <Calendar size={10} />
              {formatDate(entry.date)}
            </div>
            <p className="text-slate-300 whitespace-pre-wrap leading-relaxed font-light text-sm">
              {entry.text}
            </p>
          </Card>
        ))}
        {entries.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-slate-600 opacity-60">
            <FileText size={48} strokeWidth={1} className="mb-4" />
            <p className="text-sm font-mono uppercase">Database Empty</p>
          </div>
        )}
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="New Log Entry">
        <form onSubmit={handleSubmit} className="space-y-4">
          <TextArea 
            value={text} 
            onChange={e => setText(e.target.value)} 
            placeholder="Record your progress..." 
            rows={8}
            className="font-sans text-base leading-relaxed"
            required
            autoFocus
          />
          <Button type="submit" className="w-full">SAVE TO DATABASE</Button>
        </form>
      </Modal>
    </div>
  );
};