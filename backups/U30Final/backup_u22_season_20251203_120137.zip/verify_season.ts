import { useStore } from './store';
import { DEFAULT_SEASON } from './store';

// Helper to wait
const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

async function verifySeasonSystem() {
    console.log("--- STARTING U22 SEASON VERIFICATION ---");
    const store = useStore.getState();

    // 1. Verify Initialization
    console.log("1. Verifying Initialization...");
    if (!store.seasons || store.seasons.length === 0) {
        console.error("FAIL: Seasons array is empty.");
    } else {
        console.log("PASS: Seasons array initialized.");
    }

    if (!store.currentSeason) {
        console.error("FAIL: Current season is undefined.");
    } else {
        console.log(`PASS: Current season is ${store.currentSeason.seasonId} (Rank: ${store.currentSeason.rank}, XP: ${store.currentSeason.seasonXP})`);
    }

    // 2. Verify XP Gain from Mission
    console.log("\n2. Verifying XP Gain from Mission...");
    const initialXP = store.currentSeason?.seasonXP || 0;

    // Create a dummy mission
    store.addMission({
        title: "Test Season Mission",
        xpReward: 100,
        targetStat: "Strength",
        difficulty: "E",
        isDaily: false
    });

    // Find and complete it
    const mission = useStore.getState().missions.find(m => m.title === "Test Season Mission");
    if (mission) {
        store.completeMission(mission.id);
        await wait(100); // Wait for state update

        const newXP = useStore.getState().currentSeason?.seasonXP || 0;
        const expectedGain = Math.floor(100 * 0.5); // 50% of mission XP

        if (newXP === initialXP + expectedGain) {
            console.log(`PASS: Gained ${expectedGain} Season XP (Total: ${newXP}).`);
        } else {
            console.error(`FAIL: Expected ${initialXP + expectedGain} XP, got ${newXP}.`);
        }
    } else {
        console.error("FAIL: Could not create test mission.");
    }

    // 3. Verify Rank Progression
    console.log("\n3. Verifying Rank Progression...");
    // Force add enough XP to rank up to D (Target: 100)
    // We can't directly call addSeasonXP as it's internal, but we can simulate it via mission completion loop or just checking if previous step triggered it if we were close.
    // Let's just check if rank calculation works by manually checking the store logic (we can't easily inject XP without exposing the internal function, but we can use the mission loop).

    let currentXP = useStore.getState().currentSeason?.seasonXP || 0;
    const targetD = 100;

    if (currentXP < targetD) {
        console.log(`Current XP: ${currentXP}. Need ${targetD - currentXP} more for Rank D.`);
        // Add a big mission to force rank up
        store.addMission({
            title: "Rank Up Mission",
            xpReward: (targetD - currentXP) * 2 + 20, // Enough to cover 50% ratio
            targetStat: "Strength",
            difficulty: "S",
            isDaily: false
        });
        const bigMission = useStore.getState().missions.find(m => m.title === "Rank Up Mission");
        if (bigMission) {
            store.completeMission(bigMission.id);
            await wait(100);
        }
    }

    const updatedSeason = useStore.getState().currentSeason;
    if (updatedSeason && updatedSeason.rank !== 'E') {
        console.log(`PASS: Rank updated to ${updatedSeason.rank} (XP: ${updatedSeason.seasonXP}).`);
    } else {
        console.error(`FAIL: Rank did not update (Rank: ${updatedSeason?.rank}, XP: ${updatedSeason?.seasonXP}).`);
    }

    // 4. Verify Reward Claiming
    console.log("\n4. Verifying Reward Claiming...");
    const rank = useStore.getState().currentSeason?.rank;
    if (rank && rank !== 'E') {
        const initialStats = useStore.getState().stats;
        store.claimSeasonReward(rank);
        await wait(100);

        const finalSeason = useStore.getState().currentSeason;
        const finalStats = useStore.getState().stats;

        if (finalSeason?.claimedRewards.includes(rank)) {
            console.log(`PASS: Reward for Rank ${rank} marked as claimed.`);
        } else {
            console.error(`FAIL: Reward for Rank ${rank} NOT marked as claimed.`);
        }

        if (finalStats.xpCurrent > initialStats.xpCurrent) {
            console.log("PASS: XP Bonus applied.");
        } else {
            console.log("WARN: XP Bonus not applied (might be 0 for this rank or level up reset it).");
        }
    } else {
        console.log("SKIP: Cannot verify claiming (Rank is still E).");
    }

    console.log("\n--- VERIFICATION COMPLETE ---");
}

// Expose for console run
(window as any).verifySeason = verifySeasonSystem;
verifySeasonSystem();
