
import { AppState, AvatarFrame, Title, TitleId, AvatarFrameId } from './types';

// --- DEFINITIONS WITH LOGIC ---

export interface TitleDefinition extends Title {
  condition: (state: AppState) => boolean;
}

export interface FrameDefinition extends AvatarFrame {
  condition: (state: AppState) => boolean;
}

// --- TITLES ---

export const TITLES: TitleDefinition[] = [
  {
    id: 'disciplined',
    name: 'The Disciplined',
    description: 'Reach a 7-day streak on any mission.',
    icon: '🧘',
    condition: (state) => state.missions.some(m => (m.streak || 0) >= 7)
  },
  {
    id: 'iron_will',
    name: 'Iron Will',
    description: 'Reach a 30-day streak on any mission.',
    icon: '⛓️',
    condition: (state) => state.missions.some(m => (m.streak || 0) >= 30)
  },
  {
    id: 'shadow_breaker',
    name: 'Shadow Breaker',
    description: 'Reach 20 Strength.',
    icon: '💪',
    condition: (state) => state.stats.strength >= 20
  },
  {
    id: 'speed_walker',
    name: 'Speed Walker',
    description: 'Reach 20 Agility.',
    icon: '⚡',
    condition: (state) => state.stats.agility >= 20
  },
  {
    id: 'arcane_mind',
    name: 'Arcane Mind',
    description: 'Reach 20 Intelligence.',
    icon: '🧠',
    condition: (state) => state.stats.intelligence >= 20
  },
  {
    id: 'fortune_seeker',
    name: 'Fortune Seeker',
    description: 'Reach 20 Fortune.',
    icon: '💎',
    condition: (state) => state.stats.fortune >= 20
  },
  {
    id: 'inner_flame',
    name: 'Inner Flame',
    description: 'Reach 20 Metabolism.',
    icon: '🔥',
    condition: (state) => state.stats.metabolism >= 20
  },
  {
    id: 'monarch_candidate',
    name: 'Monarch Candidate',
    description: 'Reach Level 10.',
    icon: '👑',
    condition: (state) => state.stats.level >= 10
  },
  {
    id: 's_rank_hunter',
    name: 'S-Rank Hunter',
    description: 'Reach 50 Strength.',
    icon: '🦾',
    condition: (state) => state.stats.strength >= 50
  },
  {
    id: 'tycoon',
    name: 'Tycoon',
    description: 'Reach 50 Fortune.',
    icon: '💵',
    condition: (state) => state.stats.fortune >= 50
  },
  {
    id: 'overlord',
    name: 'Overlord',
    description: 'Reach Level 50.',
    icon: '☠️',
    condition: (state) => state.stats.level >= 50
  },
  // U21 Milestone-Exclusive Titles
  {
    id: 'shadow_rider',
    name: 'Shadow Rider',
    description: 'Complete the motorcycle license milestone.',
    icon: '🏍️',
    condition: (state) => state.milestones.some(m => m.id === 'motorcycle_license' && m.isCompleted)
  },
  {
    id: 'highway_monarch',
    name: 'Highway Monarch',
    description: 'Complete the motorcycle purchase milestone.',
    icon: '👑🏍️',
    condition: (state) => state.milestones.some(m => m.id === 'buy_motorcycle' && m.isCompleted)
  },
  {
    id: 'iron_will_master',
    name: 'Iron Will Master',
    description: 'Maintain perfect nails for 90 days.',
    icon: '💅✨',
    condition: (state) => state.milestones.some(m => m.id === 'perfect_nails_90' && m.isCompleted)
  },
  {
    id: 'gym_apostle',
    name: 'Gym Apostle',
    description: 'Complete 100 gym sessions.',
    icon: '🏋️‍♂️',
    condition: (state) => state.milestones.some(m => m.id === 'gym_100_sessions' && m.isCompleted)
  },
  {
    id: 'weight_breaker',
    name: 'Weight Breaker',
    description: 'Achieve and maintain target weight for 30 days.',
    icon: '⚖️💪',
    condition: (state) => state.milestones.some(m => m.id === 'weight_goal' && m.isCompleted)
  },
  // U22 Season Titles
  {
    id: 'season_rookie',
    name: 'Season Rookie',
    description: 'Reached Rank D in the current season.',
    icon: '🌱',
    condition: (state) => !!state.currentSeason && ['D', 'C', 'B', 'A', 'S'].includes(state.currentSeason.rank)
  },
  {
    id: 'season_challenger',
    name: 'Season Challenger',
    description: 'Reached Rank C in the current season.',
    icon: '⚔️',
    condition: (state) => !!state.currentSeason && ['C', 'B', 'A', 'S'].includes(state.currentSeason.rank)
  },
  {
    id: 'season_raider',
    name: 'Season Raider',
    description: 'Reached Rank B in the current season.',
    icon: '🛡️',
    condition: (state) => !!state.currentSeason && ['B', 'A', 'S'].includes(state.currentSeason.rank)
  },
  {
    id: 'season_vanguard',
    name: 'Season Vanguard',
    description: 'Reached Rank A in the current season.',
    icon: '⚜️',
    condition: (state) => !!state.currentSeason && ['A', 'S'].includes(state.currentSeason.rank)
  },
  {
    id: 'season_monarch',
    name: 'Season Monarch',
    description: 'Reached Rank S in the current season.',
    icon: '👑✨',
    condition: (state) => !!state.currentSeason && state.currentSeason.rank === 'S'
  }
];

// --- AVATAR FRAMES ---

export const AVATAR_FRAMES: FrameDefinition[] = [
  {
    id: 'default',
    name: 'Initiate',
    description: 'Standard system frame.',
    rarity: 'C',
    unlockDescription: 'Default',
    condition: () => true
  },
  {
    id: 'lightning',
    name: 'Storm',
    description: 'Crackling with energy.',
    rarity: 'B',
    unlockDescription: 'Reach Level 5',
    condition: (state) => state.stats.level >= 5
  },
  {
    id: 'arcane',
    name: 'Arcane',
    description: 'Mystic runes orbit the core.',
    rarity: 'A',
    unlockDescription: 'Reach Level 10',
    condition: (state) => state.stats.level >= 10
  },
  {
    id: 'inferno',
    name: 'Inferno',
    description: 'Burning passion.',
    rarity: 'A',
    unlockDescription: 'Reach Level 20',
    condition: (state) => state.stats.level >= 20
  },
  {
    id: 'shadow',
    name: 'Monarch',
    description: 'The shadow of the king.',
    rarity: 'S',
    unlockDescription: 'Unlock "S-Rank Hunter" Title',
    condition: (state) => state.stats.unlockedTitleIds.includes('s_rank_hunter')
  },
  {
    id: 'royal',
    name: 'Sovereign',
    description: 'Absolute authority.',
    rarity: 'SS',
    unlockDescription: 'Reach Level 50',
    condition: (state) => state.stats.level >= 50
  },
  // U21 Milestone-Exclusive Frames
  {
    id: 'storm_rider',
    name: 'Storm Rider',
    description: 'Cyan lightning frame with electric aura.',
    rarity: 'S',
    unlockDescription: 'Complete motorcycle license milestone',
    condition: (state) => state.milestones.some(m => m.id === 'motorcycle_license' && m.isCompleted)
  },
  {
    id: 'inner_flame_frame',
    name: 'Inner Flame',
    description: 'Blue fire aura frame.',
    rarity: 'S',
    unlockDescription: 'Complete 100 gym sessions milestone',
    condition: (state) => state.milestones.some(m => m.id === 'gym_100_sessions' && m.isCompleted)
  },
  {
    id: 'golden_fortune',
    name: 'Golden Fortune',
    description: 'Green and yellow wealth aura.',
    rarity: 'S',
    unlockDescription: 'Complete wealth-related milestone',
    condition: (state) => state.milestones.some(m => m.category === 'Wealth' && m.isCompleted)
  },
  {
    id: 'monarch_crest',
    name: 'Monarch Crest',
    description: 'Ultimate epic frame for true monarchs.',
    rarity: 'SS',
    unlockDescription: 'Complete 5 epic milestones',
    condition: (state) => state.milestones.filter(m => m.isCompleted).length >= 5
  },
  // U22 Season Frames
  {
    id: 'season_crest',
    name: 'Season Crest',
    description: 'Blue neon frame with season emblem.',
    rarity: 'A',
    unlockDescription: 'Reach Rank B in Season',
    condition: (state) => !!state.currentSeason && ['B', 'A', 'S'].includes(state.currentSeason.rank)
  },
  {
    id: 'season_monarch',
    name: 'Season Monarch',
    description: 'Legendary aura for the season ruler.',
    rarity: 'SS',
    unlockDescription: 'Reach Rank S in Season',
    condition: (state) => !!state.currentSeason && state.currentSeason.rank === 'S'
  }
];
