import React from 'react';
import { User, Zap, Trophy, Book, Calendar, Flame, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { ModuleTile } from './UIComponents';

interface GateMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: string) => void;
}

export const GateMenu: React.FC<GateMenuProps> = ({ isOpen, onClose, onNavigate }) => {
  // Ordered 2×3 grid: Profile, Skills, Achievements, Logs, Calendar, Buffs
  const tiles = [
    { id: 'Perfil', label: 'Profile', icon: <User size={24} />, accentColor: 'cyan' as const },
    { id: 'Skills', label: 'Skills', icon: <Zap size={24} />, accentColor: 'purple' as const },
    { id: 'Logros', label: 'Achievements', icon: <Trophy size={24} />, accentColor: 'amber' as const },
    { id: 'Logs', label: 'Logs', icon: <Book size={24} />, accentColor: 'slate' as const },
    { id: 'Calendar', label: 'Calendar', icon: <Calendar size={24} />, accentColor: 'teal' as const },
    { id: 'Buffs', label: 'Buffs', icon: <Flame size={24} />, accentColor: 'orange' as const },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/95 backdrop-blur-md p-6"
        >
          {/* Radial glow at top */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-600/10 blur-[100px] rounded-full pointer-events-none" />

          <div className="w-full max-w-md h-full flex flex-col relative z-10">
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-0 right-0 p-2 text-slate-500 hover:text-blue-400 transition-colors z-10"
            >
              <X size={24} />
            </button>

            {/* Header */}
            <div className="mt-12 mb-8 text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_10px_#3b82f6]"></div>
                <h2 className="text-2xl font-black text-white tracking-[0.2em] uppercase italic">
                  System <span className="text-blue-500">Modules</span>
                </h2>
              </div>
              <p className="text-slate-500 text-xs uppercase tracking-[0.3em] font-bold">Select a section</p>
            </div>

            {/* Grid - 2 columns × 3 rows */}
            <div className="grid grid-cols-2 gap-3 overflow-y-auto pb-20 scrollbar-hide max-w-sm mx-auto">
              {tiles.map((tile, index) => (
                <motion.div
                  key={tile.id}
                  initial={{ opacity: 0, scale: 0.8, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{
                    delay: index * 0.08,
                    duration: 0.3,
                    ease: [0.25, 0.1, 0.25, 1]
                  }}
                >
                  <ModuleTile
                    id={tile.id}
                    label={tile.label}
                    icon={tile.icon}
                    accentColor={tile.accentColor}
                    onClick={() => {
                      onNavigate(tile.id);
                      onClose();
                    }}
                  />
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
