
import React from 'react';
import { Brain, Dumbbell, Zap, Heart, DollarSign, Activity, Flame, Plus, Lock, Check, Shield, ChevronLeft, ChevronRight, Menu, X, Calendar, Settings, Info } from 'lucide-react';
import { StatType, Title, AvatarFrame, AvatarFrameId, LogCategory, CalendarDayData, Milestone, MilestonePhase, MilestoneCategory, MilestoneReward, RankTier, SeasonReward } from '../types';
import { MissionTemplate } from '../missionTemplates';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';

export const Card: React.FC<{ children: React.ReactNode; className?: string; onClick?: () => void }> = ({ children, className = '', onClick }) => (
  <div
    onClick={onClick}
    className={`
      bg-[#050a14]/80 backdrop-blur-sm border border-blue-900/40 rounded-lg p-4 
      shadow-[0_0_20px_rgba(15,23,42,0.4)]
      transition-all duration-200 ease-out hover:border-blue-500/50 hover:shadow-[0_0_25px_rgba(37,99,235,0.2)]
      relative overflow-hidden
      ${className}
    `}
  >
    <div className="absolute inset-0 opacity-[0.02] pointer-events-none" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
    <div className="relative z-10">{children}</div>
  </div>
);

export const Button: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'danger' | 'ghost' }> = ({ children, variant = 'primary', className = '', ...props }) => {
  const baseStyle = "px-4 py-2.5 rounded-md font-bold tracking-wide uppercase text-sm transition-all duration-200 ease-out active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100 flex items-center justify-center gap-2";
  const variants = {
    primary: "bg-blue-700 text-white border border-blue-500/60 hover:bg-blue-600 hover:border-blue-400 hover:scale-105 hover:shadow-[0_0_15px_rgba(37,99,235,0.5)]",
    secondary: "bg-slate-900 text-blue-200 border border-slate-700 hover:bg-slate-800 hover:text-white hover:border-slate-500 hover:scale-105",
    danger: "bg-red-950/50 text-red-200 border border-red-800/60 hover:bg-red-900 hover:text-red-100 hover:border-red-500 hover:scale-105 hover:shadow-[0_0_15px_rgba(239,68,68,0.4)]",
    ghost: "bg-transparent text-slate-500 hover:text-blue-300 hover:bg-blue-900/10"
  };
  return <button className={`${baseStyle} ${variants[variant]} ${className}`} {...props}>{children}</button>;
};

export const Input: React.FC<React.InputHTMLAttributes<HTMLInputElement>> = (props) => (
  <input className="w-full bg-[#02040a] border border-blue-900/40 rounded-md px-4 py-3 text-blue-50 placeholder-slate-700 focus:outline-none focus:border-blue-500 transition-colors" {...props} />
);

export const TextArea: React.FC<React.TextareaHTMLAttributes<HTMLTextAreaElement>> = (props) => (
  <textarea className="w-full bg-[#02040a] border border-blue-900/40 rounded-md px-4 py-3 text-blue-50 placeholder-slate-700 focus:outline-none focus:border-blue-500 transition-colors resize-none" {...props} />
);

export const Select: React.FC<React.SelectHTMLAttributes<HTMLSelectElement>> = (props) => (
  <div className="relative">
    <select className="w-full bg-[#02040a] border border-blue-900/40 rounded-md px-4 py-3 text-blue-50 appearance-none focus:outline-none focus:border-blue-500 transition-colors cursor-pointer" {...props}>{props.children}</select>
    <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-blue-600">▼</div>
  </div>
);

export const Modal: React.FC<{ isOpen: boolean; onClose: () => void; title: string; children: React.ReactNode }> = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 animate-in fade-in duration-200">
      <div className="bg-[#050a14] border border-blue-500/30 rounded-lg w-full max-w-md p-6 relative overflow-hidden animate-in zoom-in-95 duration-300" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-6 border-b border-blue-900/30 pb-4">
          <h2 className="text-lg font-bold text-blue-400 tracking-wider uppercase">{title}</h2>
          <button onClick={onClose} className="text-slate-600 hover:text-blue-400 transition-colors p-1">✕</button>
        </div>
        {children}
      </div>
    </div>
  );
};

export const LevelUpOverlay: React.FC<{ show: boolean; level: number }> = ({ show, level }) => {
  if (!show) return null;
  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-black/95 animate-in fade-in duration-300">
      <div className="relative animate-level-up">
        <div className="relative bg-black border border-blue-500 p-12 rounded-lg shadow-none text-center min-w-[300px]">
          <div className="absolute -top-1 -left-1 w-4 h-4 border-t-2 border-l-2 border-blue-400"></div>
          <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-2 border-r-2 border-blue-400"></div>
          <h2 className="text-5xl font-black text-white mb-2 tracking-tighter">LEVEL UP</h2>
          <div className="my-6 h-px bg-blue-900 w-full"></div>
          <div className="flex flex-col items-center gap-2">
            <span className="text-slate-500 font-mono uppercase tracking-widest text-xs">Current Level</span>
            <span className="text-6xl font-black text-blue-500 font-mono">{level}</span>
          </div>
          <div className="mt-8 grid grid-cols-2 gap-4 text-xs font-bold opacity-80 font-mono uppercase">
            <div className="text-blue-300">+ All Stats Up</div>
            <div className="text-green-400">HP Restored</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const StatIcon: React.FC<{ stat: StatType; size?: number; className?: string }> = ({ stat, size = 20, className = "" }) => {
  let animClass = "";
  let color = "";
  switch (stat) {
    case 'Strength': animClass = "animate-lightning"; color = "text-cyan-400"; return <Dumbbell size={size} className={`${className} ${animClass} ${color}`} />;
    case 'Vitality': animClass = "animate-fire-pulse"; color = "text-red-500"; return <Heart size={size} className={`${className} ${animClass} ${color}`} />;
    case 'Agility': animClass = "animate-speed-vibrate"; color = "text-yellow-400"; return <Zap size={size} className={`${className} ${animClass} ${color}`} />;
    case 'Intelligence': animClass = "animate-arcane-float"; color = "text-purple-400"; return <Brain size={size} className={`${className} ${animClass} ${color}`} />;
    case 'Fortune': animClass = "animate-shimmer-green"; color = "text-green-400"; return <DollarSign size={size} className={`${className} ${animClass} ${color}`} />;
    case 'Metabolism': animClass = "animate-plasma-morph"; color = "text-blue-400"; return <Flame size={size} className={`${className} ${animClass} ${color}`} />;
    default: return <Activity size={size} className={className} />;
  }
};

export const StatBadge: React.FC<{ stat: StatType }> = ({ stat }) => {
  let style = "";
  switch (stat) {
    case 'Strength': style = "text-cyan-400 bg-cyan-950/30 border-cyan-500/30"; break;
    case 'Vitality': style = "text-red-400 bg-red-950/30 border-red-500/30"; break;
    case 'Agility': style = "text-yellow-400 bg-yellow-950/30 border-yellow-500/30"; break;
    case 'Intelligence': style = "text-purple-400 bg-purple-950/30 border-purple-500/30"; break;
    case 'Fortune': style = "text-green-400 bg-green-950/30 border-green-500/30"; break;
    case 'Metabolism': style = "text-blue-400 bg-blue-950/30 border-blue-500/30"; break;
  }
  return (
    <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded border text-[10px] font-bold uppercase tracking-wide ${style}`}>
      <StatIcon stat={stat} size={10} />
      {stat}
    </div>
  );
};

export const TemplateChip: React.FC<{ template: MissionTemplate; onClick: () => void }> = ({ template, onClick }) => {
  const isHabit = template.category === 'Habit';
  return (
    <button onClick={onClick} className={`flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all duration-300 group whitespace-nowrap shrink-0 hover:scale-105 ${isHabit ? 'bg-slate-900/80 border-slate-700 hover:border-blue-500/50 hover:bg-slate-800' : 'bg-[#0a0502] border-yellow-900/50 hover:border-yellow-500/50 hover:bg-yellow-950/20'}`}>
      <div className={`w-5 h-5 rounded-full flex items-center justify-center border ${isHabit ? 'bg-slate-800 border-slate-600' : 'bg-yellow-950/30 border-yellow-700/50'}`}>
        <StatIcon stat={template.targetStat} size={12} />
      </div>
      <div className="flex flex-col items-start leading-none gap-0.5">
        <span className={`text-[10px] font-bold uppercase ${isHabit ? 'text-slate-300' : 'text-yellow-500'}`}>{template.label}</span>
        <span className="text-[8px] font-mono text-slate-500">{template.category}</span>
      </div>
      <Plus size={12} className="text-slate-600 group-hover:text-blue-400" />
    </button>
  );
};

export const StatCard: React.FC<{ stat: StatType; value: number; highlight?: boolean }> = ({ stat, value, highlight = false }) => {
  let styles = { border: '', text: '', bg: '', particle: '', highlightRing: '' };
  switch (stat) {
    case 'Strength': styles = { border: 'border-cyan-500/40 group-hover:border-cyan-400', text: 'text-cyan-400', bg: 'from-cyan-950/10 to-slate-950', particle: 'bg-cyan-400', highlightRing: 'ring-cyan-400' }; break;
    case 'Vitality': styles = { border: 'border-red-500/40 group-hover:border-red-400', text: 'text-red-400', bg: 'from-red-950/10 to-slate-950', particle: 'bg-red-500', highlightRing: 'ring-red-400' }; break;
    case 'Agility': styles = { border: 'border-yellow-500/40 group-hover:border-yellow-400', text: 'text-yellow-400', bg: 'from-yellow-950/10 to-slate-950', particle: 'bg-yellow-400', highlightRing: 'ring-yellow-400' }; break;
    case 'Intelligence': styles = { border: 'border-purple-500/40 group-hover:border-purple-400', text: 'text-purple-400', bg: 'from-purple-950/10 to-slate-950', particle: 'bg-purple-400', highlightRing: 'ring-purple-400' }; break;
    case 'Fortune': styles = { border: 'border-green-500/40 group-hover:border-green-400', text: 'text-green-400', bg: 'from-green-950/10 to-slate-950', particle: 'bg-green-400', highlightRing: 'ring-green-400' }; break;
    case 'Metabolism': styles = { border: 'border-blue-500/40 group-hover:border-blue-400', text: 'text-blue-400', bg: 'from-blue-950/10 to-slate-950', particle: 'bg-blue-400', highlightRing: 'ring-blue-400' }; break;
  }

  return (
    <div className={`relative group overflow-hidden rounded-lg border ${styles.border} bg-gradient-to-br ${styles.bg} transition-all duration-300 hover:scale-[1.02] cursor-default ${highlight ? `ring-2 ${styles.highlightRing} animate-pulse shadow-[0_0_20px_rgba(255,255,255,0.2)]` : ''}`}>
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '10px 10px' }}></div>
      <div className={`absolute top-2 right-2 w-0.5 h-0.5 rounded-full ${styles.particle} opacity-60`}></div>
      <div className={`absolute bottom-3 left-3 w-0.5 h-0.5 rounded-full ${styles.particle} opacity-40`}></div>
      <div className="flex flex-col items-center justify-center p-4 relative z-10">
        <div className={`relative p-3 rounded-full border border-opacity-20 mb-2 bg-slate-950 ${styles.border}`}>
          <StatIcon stat={stat} size={20} className="relative z-10" />
        </div>
        <span className="text-[9px] font-bold uppercase tracking-[0.2em] text-slate-500 mb-0.5 group-hover:text-slate-300 transition-colors">{stat}</span>
        <span className={`text-2xl font-black font-mono tracking-tighter ${styles.text}`}>{value}</span>
      </div>
    </div>
  );
};

export const StreakBadge: React.FC<{ value: number }> = ({ value }) => {
  if (!value || value <= 0) return null;
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-orange-500/10 border border-orange-500/40 px-2 py-0.5 text-[9px] font-bold text-orange-400 uppercase tracking-widest shadow-[0_0_10px_rgba(249,115,22,0.2)] animate-pulse">
      <Flame size={10} className="text-orange-500 fill-orange-500" /> {value} Day Streak
    </span>
  );
};

export const TitleCard: React.FC<{ title: Title; isUnlocked: boolean; isEquipped: boolean; onToggle: () => void }> = ({ title, isUnlocked, isEquipped, onToggle }) => {
  return (
    <div className={`relative p-4 rounded-xl border flex flex-col items-center text-center transition-all duration-300 ${isEquipped ? 'bg-blue-950/40 border-blue-400 ring-1 ring-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.15)]' : isUnlocked ? 'bg-white/5 border-blue-500/30 hover:border-blue-400 hover:bg-white/10 hover:shadow-[0_0_15px_rgba(6,182,212,0.1)]' : 'bg-slate-900/50 border-slate-800 opacity-60 grayscale'}`}>
      <div className={`text-3xl mb-3 ${isUnlocked && !isEquipped ? 'group-hover:scale-110 transition-transform' : ''} ${isEquipped ? 'animate-pulse-fast' : ''}`}>{isUnlocked ? title.icon : <Lock size={24} className="text-slate-600" />}</div>
      <h4 className={`text-xs font-black uppercase tracking-wider mb-2 ${isUnlocked ? 'text-blue-100' : 'text-slate-600'}`}>{title.name}</h4>
      <p className="text-[10px] text-slate-400 font-mono leading-tight mb-4 min-h-[2.5em] line-clamp-2">{title.description}</p>
      {isUnlocked ? (
        <button onClick={onToggle} className={`w-full py-2 rounded text-[9px] font-bold uppercase tracking-[0.15em] transition-all ${isEquipped ? 'bg-transparent text-blue-400 cursor-default' : 'bg-blue-600 text-white hover:bg-blue-500 hover:shadow-[0_0_10px_rgba(37,99,235,0.5)] active:scale-95'}`}>{isEquipped ? 'EQUIPPED' : 'EQUIP TITLE'}</button>
      ) : (
        <div className="w-full py-2 text-[10px] text-slate-600 font-bold uppercase tracking-widest border border-slate-800 rounded bg-slate-900/50 flex items-center justify-center gap-1.5"><Lock size={10} /> LOCKED</div>
      )}
      {isEquipped && <div className="absolute top-2 right-2 w-2 h-2 bg-green-500 rounded-full shadow-[0_0_8px_#22c55e] animate-pulse"></div>}
    </div>
  );
};

export const AvatarOrb: React.FC<{ level: number; initials: string; frame: AvatarFrame; imageUrl?: string; onClick?: () => void }> = ({ level, initials, frame, imageUrl, onClick }) => {
  let frameStyle = "";
  let effect = "";

  switch (frame.id) {
    case 'lightning':
      frameStyle = "border-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.5)]";
      effect = "after:absolute after:inset-[-5px] after:border-2 after:border-cyan-400/50 after:rounded-full after:animate-pulse";
      break;
    case 'arcane':
      frameStyle = "border-purple-500 shadow-[0_0_15px_rgba(168,85,247,0.5)]";
      effect = "after:absolute after:inset-[-2px] after:border after:border-purple-400 after:rounded-full after:animate-spin-slow";
      break;
    case 'inferno':
      frameStyle = "border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.6)]";
      effect = "after:absolute after:inset-[-4px] after:border-2 after:border-red-500/40 after:rounded-full after:animate-fire-pulse";
      break;
    case 'shadow':
      frameStyle = "border-blue-900 shadow-[0_0_20px_rgba(30,58,138,0.8)] bg-black";
      effect = "after:absolute after:inset-0 after:bg-blue-600/10 after:rounded-full after:animate-pulse";
      break;
    case 'royal':
      frameStyle = "border-yellow-400 shadow-[0_0_15px_rgba(250,204,21,0.6)]";
      effect = "after:absolute after:inset-[-3px] after:border after:border-yellow-200/50 after:rounded-full";
      break;
    default:
      frameStyle = "border-blue-500/50";
      effect = "";
  }

  return (
    <div className="relative group cursor-pointer w-24 h-24 mx-auto mb-4" onClick={onClick}>
      <div className={`absolute inset-0 rounded-full border-2 ${frameStyle} transition-all duration-500 ${effect} flex items-center justify-center overflow-hidden bg-slate-900`}>
        {imageUrl ? (
          <img src={imageUrl} alt="Avatar" className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity" />
        ) : (
          <span className="text-2xl font-black text-white">{initials}</span>
        )}
      </div>
      {/* Level Indicator Badge */}
      <div className="absolute -bottom-1 -right-1 bg-slate-950 border border-blue-500/50 text-blue-400 text-[10px] font-bold px-1.5 py-0.5 rounded-full z-10 shadow-sm">
        LV {level}
      </div>
    </div>
  );
};

export const AvatarFrameSelector: React.FC<{
  frames: AvatarFrame[];
  selectedId: AvatarFrameId;
  unlockedIds: AvatarFrameId[];
  onSelect: (id: AvatarFrameId) => void;
}> = ({ frames, selectedId, unlockedIds, onSelect }) => {
  return (
    <div className="flex gap-3 overflow-x-auto pb-4 pt-2 px-2 scrollbar-hide justify-center">
      {frames.map(frame => {
        const isUnlocked = unlockedIds.includes(frame.id);
        const isSelected = selectedId === frame.id;

        let borderColor = "border-slate-800";
        if (isSelected) borderColor = "border-blue-400 shadow-[0_0_10px_rgba(59,130,246,0.5)]";
        else if (isUnlocked) borderColor = "border-slate-600 hover:border-slate-400";

        return (
          <div
            key={frame.id}
            onClick={() => isUnlocked && onSelect(frame.id)}
            className={`
              flex flex-col items-center gap-2 min-w-[60px] cursor-pointer transition-all duration-300
              ${!isUnlocked ? 'opacity-50 grayscale' : 'hover:scale-105'}
            `}
          >
            <div className={`
              w-12 h-12 rounded-full border-2 ${borderColor} bg-slate-900 flex items-center justify-center relative
            `}>
              {/* Mini preview logic simplified - just showing rarity color dot */}
              <div className={`w-3 h-3 rounded-full ${frame.id === 'default' ? 'bg-slate-500' :
                frame.id === 'lightning' ? 'bg-cyan-400' :
                  frame.id === 'arcane' ? 'bg-purple-500' :
                    frame.id === 'inferno' ? 'bg-red-500' :
                      frame.id === 'shadow' ? 'bg-blue-900' : 'bg-yellow-400'
                }`}></div>
              {!isUnlocked && <Lock size={12} className="absolute text-slate-400" />}
            </div>
            <span className={`text-[9px] font-bold uppercase tracking-wider ${isSelected ? 'text-blue-400' : 'text-slate-500'}`}>
              {frame.name}
            </span>
          </div>
        );
      })}
    </div>
  );
};

export const LogCategoryBadge: React.FC<{ category: LogCategory }> = ({ category }) => {
  let colors = "bg-slate-800 text-slate-400 border-slate-700";
  switch (category) {
    case 'Mission': colors = "bg-blue-900/30 text-blue-400 border-blue-500/30"; break;
    case 'LevelUp': colors = "bg-cyan-900/30 text-cyan-400 border-cyan-500/30"; break;
    case 'Health': colors = "bg-pink-900/30 text-pink-400 border-pink-500/30"; break;
    case 'Streak': colors = "bg-yellow-900/30 text-yellow-400 border-yellow-500/30"; break;
    case 'Achievement': colors = "bg-purple-900/30 text-purple-400 border-purple-500/30"; break;
    case 'System': colors = "bg-slate-800 text-slate-400 border-slate-600"; break;
  }

  return (
    <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${colors}`}>
      {category}
    </span>
  );
};

// --- U18 NEW COMPONENTS ---

export const CalendarHeader: React.FC<{ currentDate: Date; onPrev: () => void; onNext: () => void }> = ({ currentDate, onPrev, onNext }) => {
  return (
    <div className="flex items-center justify-between px-4 py-4 bg-slate-950/50 border-b border-blue-900/30">
      <button onClick={onPrev} className="p-2 text-slate-400 hover:text-blue-400 transition-colors">
        <ChevronLeft size={20} />
      </button>
      <div className="flex flex-col items-center">
        <span className="text-lg font-black text-white uppercase tracking-widest">{format(currentDate, 'MMMM')}</span>
        <span className="text-[10px] font-mono text-blue-500 tracking-[0.3em]">{format(currentDate, 'yyyy')}</span>
      </div>
      <button onClick={onNext} className="p-2 text-slate-400 hover:text-blue-400 transition-colors">
        <ChevronRight size={20} />
      </button>
    </div>
  );
};

export const CalendarDay: React.FC<{
  date: Date;
  data: CalendarDayData;
  isCurrentMonth: boolean;
  isToday: boolean;
  isSelected: boolean;
  onClick: () => void;
  hasMilestoneActivity?: boolean;
  hasSeasonActivity?: boolean;
}> = ({ date, data, isCurrentMonth, isToday, isSelected, onClick, hasMilestoneActivity, hasSeasonActivity }) => {
  const hasMission = data.missions.length > 0 || data.xpGained > 0;
  const hasHealth = !!data.health;

  return (
    <motion.div
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={`
        aspect-square relative flex flex-col items-center justify-center rounded-lg border transition-all duration-300 cursor-pointer
        ${isSelected
          ? 'bg-blue-900/30 border-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.3)]'
          : 'bg-slate-900/20 border-slate-800 hover:border-blue-500/30 hover:bg-slate-800/50'
        }
        ${isToday ? 'ring-1 ring-blue-500 ring-offset-1 ring-offset-slate-950' : ''}
      `}
    >
      <span className={`text-xs font-bold font-mono ${isSelected ? 'text-white' : isCurrentMonth ? 'text-slate-400' : 'text-slate-700'}`}>
        {format(date, 'd')}
      </span>

      <div className="flex gap-1 mt-1">
        {hasMission && (
          <div className="w-1 h-1 rounded-full bg-blue-500 shadow-[0_0_5px_#3b82f6]"></div>
        )}
        {hasHealth && (
          <div className="w-1 h-1 rounded-full bg-purple-500 shadow-[0_0_5px_#a855f7]"></div>
        )}
        {hasMilestoneActivity && (
          <div className="w-1 h-1 rounded-full bg-yellow-500 shadow-[0_0_5px_#eab308]"></div>
        )}
        {hasSeasonActivity && (
          <div className="absolute -top-1 -right-1 text-[8px]">👑</div>
        )}
      </div>

      {isToday && (
        <div className="absolute inset-0 rounded-lg border border-blue-500/20 animate-pulse"></div>
      )}
    </motion.div>
  );
};

export const HamburgerMenu: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  items: { id: string; label: string; icon: React.ReactNode; onClick: () => void }[]
}> = ({ isOpen, onClose, items }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 bottom-0 w-64 bg-[#030712] border-l border-blue-900/50 z-[51] shadow-[-10px_0_30px_rgba(0,0,0,0.8)]"
          >
            <div className="p-6 border-b border-blue-900/20 flex justify-between items-center">
              <h2 className="text-lg font-black text-white italic tracking-wider">SYSTEM MENU</h2>
              <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors">
                <X size={24} />
              </button>
            </div>

            <div className="p-4 flex flex-col gap-2">
              {items.map(item => (
                <button
                  key={item.id}
                  onClick={() => { item.onClick(); onClose(); }}
                  className="flex items-center gap-4 p-3 rounded-lg hover:bg-blue-900/20 text-slate-400 hover:text-blue-400 transition-all group"
                >
                  <div className="group-hover:scale-110 transition-transform text-blue-600 group-hover:text-blue-400">
                    {item.icon}
                  </div>
                  <span className="font-bold uppercase tracking-widest text-xs">{item.label}</span>
                </button>
              ))}
            </div>

            <div className="absolute bottom-0 left-0 right-0 p-6 border-t border-blue-900/20">
              <div className="text-[10px] text-slate-600 font-mono text-center">
                SYSTEM VERSION 1.18.0<br />
                PLAYER ID: #001
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

// --- U18.1 MODULE TILE ---

export const ModuleTile: React.FC<{
  id: string;
  label: string;
  icon: React.ReactNode;
  accentColor: 'cyan' | 'purple' | 'amber' | 'slate' | 'teal' | 'orange';
  onClick: () => void;
}> = ({ label, icon, accentColor, onClick }) => {
  const colorStyles = {
    cyan: {
      border: 'border-cyan-500/20 hover:border-cyan-400/50',
      iconBg: 'bg-cyan-950/30 border-cyan-500/30',
      iconText: 'text-cyan-400',
      shadow: 'hover:shadow-[0_0_30px_rgba(6,182,212,0.3)]',
      glow: 'group-hover:shadow-[0_0_15px_rgba(6,182,212,0.4)]'
    },
    purple: {
      border: 'border-purple-500/20 hover:border-purple-400/50',
      iconBg: 'bg-purple-950/30 border-purple-500/30',
      iconText: 'text-purple-400',
      shadow: 'hover:shadow-[0_0_30px_rgba(168,85,247,0.3)]',
      glow: 'group-hover:shadow-[0_0_15px_rgba(168,85,247,0.4)]'
    },
    amber: {
      border: 'border-amber-500/20 hover:border-amber-400/50',
      iconBg: 'bg-amber-950/30 border-amber-500/30',
      iconText: 'text-amber-400',
      shadow: 'hover:shadow-[0_0_30px_rgba(251,191,36,0.3)]',
      glow: 'group-hover:shadow-[0_0_15px_rgba(251,191,36,0.4)]'
    },
    slate: {
      border: 'border-slate-500/20 hover:border-slate-400/50',
      iconBg: 'bg-slate-950/30 border-slate-500/30',
      iconText: 'text-slate-400',
      shadow: 'hover:shadow-[0_0_30px_rgba(100,116,139,0.3)]',
      glow: 'group-hover:shadow-[0_0_15px_rgba(100,116,139,0.4)]'
    },
    teal: {
      border: 'border-teal-500/20 hover:border-teal-400/50',
      iconBg: 'bg-teal-950/30 border-teal-500/30',
      iconText: 'text-teal-400',
      shadow: 'hover:shadow-[0_0_30px_rgba(20,184,166,0.3)]',
      glow: 'group-hover:shadow-[0_0_15px_rgba(20,184,166,0.4)]'
    },
    orange: {
      border: 'border-orange-500/20 hover:border-orange-400/50',
      iconBg: 'bg-orange-950/30 border-orange-500/30',
      iconText: 'text-orange-400',
      shadow: 'hover:shadow-[0_0_30px_rgba(249,115,22,0.3)]',
      glow: 'group-hover:shadow-[0_0_15px_rgba(249,115,22,0.4)]'
    }
  };

  const styles = colorStyles[accentColor];

  return (
    <motion.button
      whileHover={{ y: -2, scale: 1.02 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={`
        group relative overflow-hidden rounded-2xl border ${styles.border}
        bg-slate-900/60 backdrop-blur-sm
        shadow-[0_0_25px_rgba(15,23,42,0.8)] ${styles.shadow}
        transition-all duration-300 ease-out
        aspect-square flex flex-col items-center justify-center p-6
      `}
    >
      {/* Subtle grid overlay */}
      <div className="absolute inset-0 opacity-[0.02] pointer-events-none" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>

      {/* Icon container */}
      <div className={`
        relative p-4 rounded-full border ${styles.iconBg}
        mb-3 transition-all duration-300
        ${styles.glow}
      `}>
        <div className={`${styles.iconText}`}>
          {icon}
        </div>
      </div>

      {/* Label */}
      <span className="text-xs font-bold uppercase tracking-[0.2em] text-slate-200 group-hover:text-white transition-colors">
        {label}
      </span>

      {/* Hover glow effect */}
      <div className="absolute inset-0 rounded-2xl bg-white/0 group-hover:bg-white/5 transition-colors duration-300 pointer-events-none" />
    </motion.button>
  );
};

// --- U21 MILESTONE COMPONENTS ---

export const SegmentedControl: React.FC<{
  options: string[];
  selected: string;
  onChange: (value: string) => void;
}> = ({ options, selected, onChange }) => {
  return (
    <div className="flex p-1 bg-slate-950/50 rounded-lg border border-blue-900/30 relative">
      <div className="absolute inset-0 bg-blue-900/10 rounded-lg pointer-events-none"></div>
      {options.map((option) => {
        const isSelected = selected === option;
        return (
          <button
            key={option}
            onClick={() => onChange(option)}
            className={`
              flex-1 py-2 text-xs font-bold uppercase tracking-wider rounded-md transition-all duration-300 relative z-10
              ${isSelected ? 'text-white bg-blue-600 shadow-[0_0_15px_rgba(37,99,235,0.4)]' : 'text-slate-500 hover:text-blue-300 hover:bg-white/5'}
            `}
          >
            {option}
          </button>
        );
      })}
    </div>
  );
};

export const MilestoneCategoryBadge: React.FC<{ category: MilestoneCategory }> = ({ category }) => {
  let colors = "bg-slate-800 text-slate-400 border-slate-700";
  switch (category) {
    case 'Health': colors = "bg-red-950/30 text-red-400 border-red-500/30"; break;
    case 'Wealth': colors = "bg-green-950/30 text-green-400 border-green-500/30"; break;
    case 'Skill': colors = "bg-blue-950/30 text-blue-400 border-blue-500/30"; break;
    case 'Lifestyle': colors = "bg-purple-950/30 text-purple-400 border-purple-500/30"; break;
    case 'Other': colors = "bg-slate-800 text-slate-400 border-slate-600"; break;
  }

  return (
    <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${colors}`}>
      {category}
    </span>
  );
};

export const MilestoneRewardBadge: React.FC<{ reward: MilestoneReward }> = ({ reward }) => {
  return (
    <div className="flex gap-2">
      {reward.xpBonus && (
        <span className="text-[9px] font-bold text-blue-400 bg-blue-950/30 px-1.5 py-0.5 rounded border border-blue-500/30">+{reward.xpBonus} XP</span>
      )}
      {reward.statBonus && (
        <span className="text-[9px] font-bold text-yellow-400 bg-yellow-950/30 px-1.5 py-0.5 rounded border border-yellow-500/30">STATS</span>
      )}
      {reward.unlockTitleId && (
        <span className="text-[9px] font-bold text-purple-400 bg-purple-950/30 px-1.5 py-0.5 rounded border border-purple-500/30">TITLE</span>
      )}
      {reward.unlockFrameId && (
        <span className="text-[9px] font-bold text-cyan-400 bg-cyan-950/30 px-1.5 py-0.5 rounded border border-cyan-500/30">FRAME</span>
      )}
    </div>
  );
};

export const PhaseProgressBar: React.FC<{ current: number; total: number }> = ({ current, total }) => {
  const percent = Math.min(100, (current / total) * 100);
  return (
    <div className="h-1.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
      <div
        className="h-full bg-gradient-to-r from-blue-600 to-cyan-400 transition-all duration-500 ease-out shadow-[0_0_10px_rgba(6,182,212,0.5)]"
        style={{ width: `${percent}%` }}
      ></div>
    </div>
  );
};

export const MilestoneCard: React.FC<{
  milestone: Milestone;
  onAction: () => void;
}> = ({ milestone, onAction }) => {
  const currentPhase = milestone.phases[milestone.currentPhaseIndex];
  const isFullyCompleted = milestone.isCompleted;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`
        relative overflow-hidden rounded-xl border p-5 transition-all duration-300
        ${isFullyCompleted
          ? 'bg-blue-950/20 border-blue-500/50 shadow-[0_0_20px_rgba(37,99,235,0.2)]'
          : 'bg-[#050a14]/90 border-blue-900/30 hover:border-blue-500/30'
        }
      `}
    >
      {/* Background Grid */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '30px 30px' }}></div>

      <div className="relative z-10">
        <div className="flex justify-between items-start mb-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <MilestoneCategoryBadge category={milestone.category} />
              {milestone.targetDate && (
                <span className="text-[9px] font-mono text-slate-500 flex items-center gap-1">
                  <Calendar size={10} /> {milestone.targetDate}
                </span>
              )}
            </div>
            <h3 className={`text-lg font-black uppercase tracking-wide ${isFullyCompleted ? 'text-blue-300' : 'text-white'}`}>
              {milestone.title}
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed max-w-[90%]">{milestone.description}</p>
          </div>
          {isFullyCompleted && (
            <div className="bg-blue-500/20 text-blue-300 border border-blue-500/50 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-widest animate-pulse">
              Completed
            </div>
          )}
        </div>

        {!isFullyCompleted && (
          <div className="bg-slate-900/50 rounded-lg p-3 border border-slate-800 mb-4">
            <div className="flex justify-between items-center mb-2 text-xs">
              <span className="font-bold text-blue-200 uppercase tracking-wider">
                Phase {milestone.currentPhaseIndex + 1} <span className="text-slate-600">/</span> {milestone.phases.length}
              </span>
              <span className="font-mono text-slate-500">
                {currentPhase.completedActions} / {currentPhase.requiredActions}
              </span>
            </div>
            <h4 className="text-xs font-bold text-slate-300 mb-2">{currentPhase.title}</h4>
            <PhaseProgressBar current={currentPhase.completedActions} total={currentPhase.requiredActions} />
          </div>
        )}

        <div className="flex justify-between items-center mt-2">
          <MilestoneRewardBadge reward={milestone.reward} />

          {!isFullyCompleted && (
            <Button
              variant="primary"
              onClick={onAction}
              className="py-1.5 px-3 text-xs"
              disabled={currentPhase.isCompleted} // Disable if phase just completed but not advanced (though logic handles auto-advance)
            >
              <Plus size={14} /> Progress
            </Button>
          )}
        </div>
      </div>
    </motion.div>
  );
};

// --- U22 SEASON COMPONENTS ---

export const RankPill: React.FC<{ rank: RankTier; size?: 'sm' | 'md' | 'lg' }> = ({ rank, size = 'md' }) => {
  let colors = "";
  switch (rank) {
    case 'E': colors = "bg-slate-800 text-slate-400 border-slate-700"; break;
    case 'D': colors = "bg-slate-700 text-white border-slate-500"; break;
    case 'C': colors = "bg-green-900/40 text-green-400 border-green-500/40"; break;
    case 'B': colors = "bg-blue-900/40 text-blue-400 border-blue-500/40"; break;
    case 'A': colors = "bg-purple-900/40 text-purple-400 border-purple-500/40"; break;
    case 'S': colors = "bg-yellow-900/40 text-yellow-400 border-yellow-500/40 shadow-[0_0_10px_rgba(234,179,8,0.3)] animate-pulse"; break;
  }

  const sizeClasses = size === 'sm' ? 'text-[9px] px-1.5 py-0.5' : size === 'lg' ? 'text-xl px-4 py-1' : 'text-xs px-2 py-1';

  return (
    <span className={`font-black font-mono rounded border ${colors} ${sizeClasses} inline-flex items-center justify-center`}>
      {rank}
    </span>
  );
};

export const SeasonBadge: React.FC<{ name: string; rank: RankTier; progress: number; onClick?: () => void }> = ({ name, rank, progress, onClick }) => {
  return (
    <button onClick={onClick} className="group relative flex items-center gap-3 bg-[#050a14] border border-blue-900/50 rounded-full pl-1 pr-4 py-1 hover:border-blue-500/50 hover:shadow-[0_0_15px_rgba(37,99,235,0.2)] transition-all">
      <RankPill rank={rank} size="sm" />
      <div className="flex flex-col items-start">
        <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider group-hover:text-blue-300 transition-colors">{name}</span>
        <div className="w-16 h-1 bg-slate-800 rounded-full overflow-hidden mt-0.5">
          <div className="h-full bg-blue-500 shadow-[0_0_5px_#3b82f6]" style={{ width: `${progress}%` }}></div>
        </div>
      </div>
    </button>
  );
};

export const SeasonTierCard: React.FC<{
  tier: RankTier;
  xpRequired: number;
  status: 'LOCKED' | 'REACHED' | 'CLAIMED';
  rewards: SeasonReward;
  onClaim: () => void;
}> = ({ tier, xpRequired, status, rewards, onClaim }) => {
  const isLocked = status === 'LOCKED';
  const isClaimed = status === 'CLAIMED';
  const canClaim = status === 'REACHED';

  return (
    <div className={`
      relative flex items-center gap-4 p-4 rounded-xl border transition-all duration-300
      ${isLocked ? 'bg-slate-900/20 border-slate-800 opacity-50 grayscale' : ''}
      ${canClaim ? 'bg-blue-950/30 border-blue-500/50 shadow-[0_0_20px_rgba(37,99,235,0.2)]' : ''}
      ${isClaimed ? 'bg-slate-900/50 border-slate-700' : ''}
    `}>
      {/* Rank Icon */}
      <div className="flex flex-col items-center gap-1 min-w-[3rem]">
        <RankPill rank={tier} size="lg" />
        <span className="text-[9px] font-mono text-slate-500">{xpRequired} XP</span>
      </div>

      {/* Rewards List */}
      <div className="flex-1">
        <div className="flex flex-wrap gap-2 mb-2">
          {rewards.xpBonus && (
            <span className="text-[10px] font-bold text-blue-300 bg-blue-900/20 px-2 py-0.5 rounded border border-blue-500/20">+{rewards.xpBonus} XP</span>
          )}
          {rewards.statBonus && (
            <span className="text-[10px] font-bold text-yellow-300 bg-yellow-900/20 px-2 py-0.5 rounded border border-yellow-500/20">STATS</span>
          )}
          {rewards.unlockTitleId && (
            <span className="text-[10px] font-bold text-purple-300 bg-purple-900/20 px-2 py-0.5 rounded border border-purple-500/20">TITLE</span>
          )}
          {rewards.unlockFrameId && (
            <span className="text-[10px] font-bold text-cyan-300 bg-cyan-900/20 px-2 py-0.5 rounded border border-cyan-500/20">FRAME</span>
          )}
        </div>
      </div>

      {/* Action Button */}
      <div>
        {isClaimed ? (
          <div className="flex items-center gap-1 text-green-500 font-bold text-[10px] uppercase tracking-wider bg-green-950/20 px-3 py-1.5 rounded border border-green-900/50">
            <Check size={12} /> Claimed
          </div>
        ) : canClaim ? (
          <Button variant="primary" onClick={onClaim} className="animate-pulse shadow-[0_0_10px_rgba(37,99,235,0.5)]">
            Claim
          </Button>
        ) : (
          <div className="flex items-center gap-1 text-slate-600 font-bold text-[10px] uppercase tracking-wider">
            <Lock size={12} /> Locked
          </div>
        )}
      </div>
    </div>
  );
};
